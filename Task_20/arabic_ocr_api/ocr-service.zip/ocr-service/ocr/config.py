"""
Loads the deployment artifacts (model / vocab / config) produced by the
training notebook's "Save the Best Model" step. Point ARTIFACTS_DIR at
wherever you copied that deployment_artifacts/ folder to.
"""

import json
import os

ARTIFACTS_DIR = os.environ.get("ARTIFACTS_DIR", "deployment_artifacts")

MODEL_PATH = os.path.join(ARTIFACTS_DIR, "crnn_ocr_model.keras")
VOCAB_PATH = os.path.join(ARTIFACTS_DIR, "vocab.json")
CONFIG_PATH = os.path.join(ARTIFACTS_DIR, "config.json")


def _require(path: str, hint: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{hint} not found at '{path}'. Copy the deployment_artifacts/ "
            f"folder produced by the training notebook into this project "
            f"(or set the ARTIFACTS_DIR environment variable)."
        )
    return path


def load_config() -> dict:
    _require(CONFIG_PATH, "config.json")
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def load_vocab() -> list:
    _require(VOCAB_PATH, "vocab.json")
    with open(VOCAB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)
